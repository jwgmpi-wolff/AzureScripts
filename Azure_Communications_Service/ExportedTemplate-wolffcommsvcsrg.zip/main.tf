AzAPI Terrform resource failed to load  : AzAPI
{
    "type": "FxAjaxBatchResponseItemError",
    "baseTypes": [
        "FxAjaxBatchResponseItemError",
        "MsPortalFx.Errors.Error"
    ],
    "extension": "HubsExtension",
    "errorLevel": 2,
    "timestamp": 902906.2000000477,
    "name": "BatchResponseItemError",
    "innerErrors": [],
    "content": {
        "error": {
            "code": "RPNotRegistered",
            "message": "getting resource provider Microsoft.AzureTerraform: GET https://management.azure.com/subscriptions/5755893a-8056-4ba8-9916-1133c80a80f3/providers/Microsoft.AzureTerraform\n--------------------------------------------------------------------------------\nRESPONSE 401: 401 Unauthorized\nERROR CODE: InvalidAuthenticationToken\n--------------------------------------------------------------------------------\n{\n  \"error\": {\n    \"code\": \"InvalidAuthenticationToken\",\n    \"message\": \"The received access token is not valid: at least one of the claims 'puid' or 'altsecid' or 'oid' should be present. If you are accessing as application please make sure service principal is properly created in the tenant.\"\n  }\n}\n--------------------------------------------------------------------------------\n. Refer to documentation how to register at https://aka.ms/AzureTerraformRPRegistration"
        }
    },
    "headers": {
        "cache-control": "no-cache",
        "content-length": "944",
        "content-type": "application/json",
        "date": "Tue, 22 Apr 2025 23:45:04 GMT",
        "expires": "-1",
        "pragma": "no-cache",
        "x-ms-correlation-request-id": "62b5f472-3508-420a-a98e-f30c6a76a28a",
        "x-ms-failure-cause": "service",
        "x-ms-operation-identifier": "tenantId=e594a530-1ec9-4192-a8d4-a9111f8cffa7,objectId=21fab876-a421-4e7c-a0b6-9b3fb509ff85/westus/c4e12a6d-f6c7-49ae-904d-613439647734",
        "x-ms-providerhub-traffic": "True",
        "x-ms-ratelimit-remaining-subscription-global-writes": "2999",
        "x-ms-ratelimit-remaining-subscription-writes": "19999",
        "x-ms-request-id": "88805132-f94e-46a1-8a5b-9344f26aa74f",
        "x-ms-routing-request-id": "WESTUS:20250422T234504Z:62b5f472-3508-420a-a98e-f30c6a76a28a"
    },
    "httpStatusCode": 400
}