import json
import os
import re
import sqlite3
import time
from collections import Counter
from pathlib import Path

import requests
from bs4 import BeautifulSoup
from flask import Flask, render_template, request, jsonify

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "search_intelligence.db"
TEMPLATE_DIR = BASE_DIR / "templates"
STATIC_DIR = BASE_DIR / "static"

app = Flask(__name__, template_folder=str(TEMPLATE_DIR), static_folder=str(STATIC_DIR))


def init_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS searches (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            query TEXT NOT NULL,
            filters TEXT,
            result_count INTEGER DEFAULT 0,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS search_results (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            search_id INTEGER NOT NULL,
            title TEXT,
            url TEXT,
            snippet TEXT,
            source TEXT,
            score REAL DEFAULT 0,
            FOREIGN KEY(search_id) REFERENCES searches(id)
        )
        """
    )
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS learning_terms (
            term TEXT PRIMARY KEY,
            weight REAL DEFAULT 1.0
        )
        """
    )
    conn.commit()
    conn.close()


init_db()


def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def fetch_duckduckgo(query: str, max_results: int = 8):
    url = "https://duckduckgo.com/html/"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
    }
    params = {"q": query, "kl": "us-en"}
    try:
        resp = requests.get(url, headers=headers, params=params, timeout=20)
        resp.raise_for_status()
    except Exception:
        return []

    soup = BeautifulSoup(resp.text, "html.parser")
    items = []
    for a in soup.select("a.result__a")[:max_results]:
        title = a.get_text(" ", strip=True)
        href = a.get("href")
        if not href or href.startswith("http://") or href.startswith("https://"):
            pass
        # extract snippet from adjacent result__snippet or fallback
        snippet = ""
        parent = a.find_parent("a")
        if parent is not None:
            snippet_node = parent.find_next_sibling(["a", "div"])
            if snippet_node is not None:
                snippet = snippet_node.get_text(" ", strip=True)
        items.append({"title": title, "url": href, "snippet": snippet or "Public web result"})
    return items


def score_result(result, query_terms, learning_weights):
    title = (result.get("title") or "").lower()
    snippet = (result.get("snippet") or "").lower()
    url = (result.get("url") or "").lower()
    text = " ".join([title, snippet, url])

    score = 0.0
    for term in query_terms:
        if term in text:
            score += 1.5
    for term, weight in learning_weights.items():
        if term in text:
            score += weight

    # small noise reduction for very generic terms
    if len(query_terms) == 1:
        score += 0.2
    return round(score, 2)


def load_learning_weights():
    conn = get_conn()
    rows = conn.execute("SELECT term, weight FROM learning_terms").fetchall()
    conn.close()
    return {row["term"]: row["weight"] for row in rows}


def update_learning_weights(query_terms, scores):
    conn = get_conn()
    for term in query_terms:
        existing = conn.execute("SELECT weight FROM learning_terms WHERE term = ?", (term,)).fetchone()
        current = existing["weight"] if existing else 1.0
        new_weight = current + 0.15 * (sum(scores) / max(len(scores), 1))
        conn.execute("INSERT INTO learning_terms(term, weight) VALUES(?, ?) ON CONFLICT(term) DO UPDATE SET weight = excluded.weight", (term, new_weight))
    conn.commit()
    conn.close()


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/search", methods=["POST"])
def search():
    query = request.form.get("query", "").strip()
    filters = {
        "entity": request.form.get("entity", "public"),
        "source": request.form.get("source", "all"),
        "max_results": int(request.form.get("max_results", 8) or 8),
    }

    if not query:
        return jsonify({"error": "Provide at least one search term."}), 400

    query_terms = [t for t in re.findall(r"[A-Za-z0-9]+", query.lower()) if len(t) > 2]
    learning_weights = load_learning_weights()

    candidate_results = fetch_duckduckgo(query, max_results=filters["max_results"])
    scored = []
    for item in candidate_results:
        score = score_result(item, query_terms, learning_weights)
        scored.append({**item, "score": score, "source": filters["source"] if filters["source"] != "all" else "web"})

    scored_sorted = sorted(scored, key=lambda x: x["score"], reverse=True)
    result_count = len(scored_sorted)

    conn = get_conn()
    cur = conn.cursor()
    cur.execute("INSERT INTO searches(query, filters, result_count) VALUES(?, ?, ?)", (query, json.dumps(filters), result_count))
    search_id = cur.lastrowid
    for item in scored_sorted:
        cur.execute(
            "INSERT INTO search_results(search_id, title, url, snippet, source, score) VALUES(?, ?, ?, ?, ?, ?)",
            (search_id, item["title"], item["url"], item["snippet"], item["source"], item["score"])
        )
    conn.commit()
    conn.close()

    update_learning_weights(query_terms, [item["score"] for item in scored_sorted])

    return jsonify({
        "query": query,
        "filters": filters,
        "results": scored_sorted,
        "search_id": search_id,
        "learning_terms": load_learning_weights(),
    })


@app.route("/history")
def history():
    conn = get_conn()
    searches = conn.execute("SELECT * FROM searches ORDER BY id DESC LIMIT 10").fetchall()
    conn.close()
    return jsonify([dict(row) for row in searches])


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=int(os.getenv("PORT", 5000)))
