# Public Search Intelligence Prototype

This folder contains a low-cost, local prototype for:
- a search UI with navigation and public-link browsing
- SQLite-backed result storage
- simple relevance-learning weights that improve future ranking

Important note:
This prototype intentionally avoids invasive personal-data collection and facial-recognition features. It is designed for public, consent-based research and public-source discovery only.

## Run

1. python -m venv .venv
2. .\.venv\Scripts\activate
3. pip install -r requirements.txt
4. python app.py

Open http://localhost:5000
