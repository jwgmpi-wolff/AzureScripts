import requests
from bs4 import BeautifulSoup

url='https://search.brave.com/search'
h={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36','Accept-Language':'en-US,en;q=0.9'}
r=requests.get(url,headers=h,params={'q':'microsoft public profile'},timeout=15)
print('status', r.status_code, 'len', len(r.text))
soup=BeautifulSoup(r.text,'html.parser')
links=[]
for a in soup.find_all('a', href=True):
    href=a['href']
    txt=' '.join(a.get_text(' ', strip=True).split())
    if href.startswith('http') and len(txt) > 4 and 'brave.com' not in href:
        links.append((txt, href))
print('anchors', len(links))
for x in links[:40]:
    print(x)
